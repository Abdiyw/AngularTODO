import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
todoArray:any=[];
estadoArray: any[] = [];

guardarTarea(value:any){
  if(value !==""){
    this.todoArray.push(value);
    this.estadoArray.push(value);
    console.log(this.todoArray);
  }else{
    alert('El campo tarea es requerido.')
  }
}
borrarTarea(item:any){
  for(let i=0; i <= this.todoArray.length; i++){
    if(item == this.todoArray[i]){
      this.todoArray.splice(i,1);
      this.estadoArray.splice(i,1);
    }
  }
}
Completar(item:any){
  for(let i=0;i<=this.estadoArray.length;i++){
    if(item == this.estadoArray[i]){
      this.estadoArray[i]="Completo";
    }
  }
}


}


